package com.lgy.recipe.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.lgy.recipe.dto.RecipeDTO;
import com.lgy.recipe.service.RecipeService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequestMapping("/recipe")
public class RecipeController {
	@Autowired
	private RecipeService service;

	@Autowired
	private ServletContext servletContext;

	@RequestMapping("/addRecipe")
	public String addRecipe() {
		return "recipe/insertRecipe"; // ✅ 수정
	}

	@RequestMapping("/recipe_write")
	public String insertRecipe(@RequestParam HashMap<String, String> params,
			@RequestParam("rc_ingredient_name[]") List<String> rc_ingredient_name,
			@RequestParam("rc_ingredient_amount[]") List<String> rc_ingredient_amount,
			@RequestParam("rc_course_description[]") List<String> rc_course_description,
			@RequestParam("mf_id") String mf_id, Model model
//			@RequestParam("rc_ingredient_name[]") List<String> ingredientNames,
//			@RequestParam("rc_ingredient_amount[]") List<String> ingredientAmounts,
//			@RequestParam("rc_course_description[]") List<String> courseDescriptions
//			@RequestParam("rc_course_img[]") List<MultipartFile> courseImages,
//			@RequestParam("rc_img") MultipartFile mainImage, HttpServletRequest request
	) {
//		log.info("!@# params" + params);
		System.out.println("!@# params" + params);
		System.out.println("!@# ingredientAmounts" + rc_ingredient_amount);
		System.out.println("!@# courseDescriptions" + rc_course_description);
		System.out.println("!@# ingredientNames" + rc_ingredient_name);
//		System.out.println("!@# params" + mainImage);
		// 대표 이미지 저장
//		String mainImagePath = saveImage(mainImage, request);

		// 레시피 정보 저장 (Map으로 구성)
		HashMap<String, String> recipeData = new HashMap<>();
		recipeData.put("rc_name", params.get("rc_name"));
		recipeData.put("rc_description", params.get("rc_description"));
		recipeData.put("rc_category1_id", params.get("rc_category1_id"));
		recipeData.put("rc_cooking_time", params.get("rc_cooking_time"));
		recipeData.put("rc_difficulty", params.get("rc_difficulty"));
		recipeData.put("rc_tip", params.get("rc_tip"));
		recipeData.put("rc_tag", params.get("rc_tag"));
//		recipeData.put("rc_main_img", mainImagePath); // DB 저장 필요 시 사용

		System.out.println("insert recipe #1");

		System.out.println(recipeData);
		// insert 및 생성된 ID 추출
		service.insert_recipe(recipeData);
		System.out.println("insert recipe #1-1");

//		int recipeId = service.recipe_list().getRc_recipe_id();
		System.out.println("insert recipe #2");

//
//		// 재료 저장
//		List<RcIngredientDTO> ingredients = new ArrayList<>();
//		for (int i = 0; i < ingredientNames.size(); i++) {
//			RcIngredientDTO ing = new RcIngredientDTO();
////			ing.setRc_recipe_id(recipeId);
//			ing.setRc_ingredient_name(ingredientNames.get(i));
//			ing.setRc_ingredient_amount(ingredientAmounts.get(i));
//			ingredients.add(ing);
//		}
//		service.insert_rc_ingredients(ingredients);
//		System.out.println("insert recipe #3");
		// 재료 저장
		System.out.println(rc_course_description);
		System.out.println(rc_ingredient_amount);
		System.err.println(rc_ingredient_name);

		for (int i = 0; i < rc_course_description.size(); i++) {
			service.insert_rc_course(rc_course_description.get(i));
		}

		for (int i = 0; i < rc_ingredient_name.size(); i++) {
			service.insert_rc_ingredient(rc_ingredient_name.get(i), rc_ingredient_amount.get(i));
		}

//
////		// 조리 과정 저장
//		List<RcCourseDTO> courses = new ArrayList<>();
//		for (int i = 0; i < courseDescriptions.size(); i++) {
//			RcCourseDTO course = new RcCourseDTO();
////			course.setRc_recipe_id(recipeId);
//			course.setRc_course_description(courseDescriptions.get(i));
////			String imgPath = saveImage(courseImages.get(i), request);
////			course.setRc_course_img(imgPath);
//			courses.add(course);
//		}
//		System.out.println("insert recipe #4");
//		service.insert_rc_courses(courses);
//		System.out.println("insert recipe #5");
		// 조리 과정 저장
		model.addAttribute("mf_id", mf_id);
		return "redirect:/member/profile";
	}

	@RequestMapping("/recipeDetail")
	public String recipeDetail(@RequestParam("id") int recipeId, Model model) {
		try {
			RecipeDTO recipe = service.get_recipe_by_id(recipeId);
			if (recipe == null) {
				model.addAttribute("errorMessage", "해당 레시피를 찾을 수 없습니다.");
				return "recipe/errorPage"; // ✅ 수정
			}
			model.addAttribute("recipe", recipe);
			return "recipe/recipeDetail"; // ✅ 수정
		} catch (Exception e) {
			model.addAttribute("errorMessage", "레시피 상세 조회 중 오류가 발생했습니다.");
			return "errorPage"; // 에러 페이지로 이동
		}
	}

	/**
	 * 레시피 수정 페이지로 이동
	 */
	@RequestMapping("/editRecipe")
	public String editRecipe(@RequestParam("id") int recipeId, Model model) {
		try {
			RecipeDTO recipe = service.get_recipe_by_id(recipeId);
			if (recipe == null) {
				model.addAttribute("errorMessage", "해당 레시피를 수정할 수 없습니다.");
				return "recipe/errorPage"; // ✅ 수정
			}
			model.addAttribute("recipe", recipe);
			return "recipe/recipeEdit"; // ✅ 수정
		} catch (Exception e) {
			model.addAttribute("errorMessage", "레시피 수정 페이지 로드 중 오류가 발생했습니다.");
			return "recipe/errorPage"; // ✅ 수정
		}
	}

	/**
	 * 레시피 수정 처리
	 */
	@PostMapping("/updateRecipe")
	public String updateRecipe(@RequestParam("rc_recipe_id") String id, @RequestParam("rc_name") String name,
			@RequestParam("rc_description") String description, @RequestParam("rc_category1_id") String cat1,
			@RequestParam("rc_category2_id") String cat2, @RequestParam("rc_cooking_time") String time,
			@RequestParam("rc_difficulty") String difficulty, @RequestParam("existing_image") String existingImage, // 기존
																													// 이미지
			@RequestParam(value = "uploadFile", required = false) MultipartFile file, HttpServletRequest request,
			Model model) {
		try {
			String fileName = existingImage;

			if (file != null && !file.isEmpty()) {
				String uploadPath = request.getSession().getServletContext().getRealPath("/resources/images/");
				fileName = file.getOriginalFilename();
				File saveFile = new File(uploadPath, fileName);
				file.transferTo(saveFile);
			}

			HashMap<String, String> param = new HashMap();
			param.put("rc_recipe_id", id);
			param.put("rc_name", name);
			param.put("rc_description", description);
			param.put("rc_category1_id", cat1);
			param.put("rc_category2_id", cat2);
			param.put("rc_cooking_time", time);
			param.put("rc_difficulty", difficulty);
			param.put("rc_image_name", fileName);

			service.updateRecipe(param);
			return "redirect:/recipe/recipeDetail?id=" + id; // ✅ URL 기준 redirect

		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("errorMessage", "레시피 수정 실패");
			return "recipe/recipeEdit"; // ✅ 수정
		}
	}

	@RequestMapping("/deleteRecipe")
	public String deleteRecipe(@RequestParam("id") int recipeId, Model model) {
		try {
			service.deleteRecipe(recipeId); // 👈 여기서 int 그대로 넘깁니다
			return "redirect:/recipe/recipeList"; // ✅ 수정
		} catch (Exception e) {
			model.addAttribute("errorMessage", "레시피 삭제에 실패했습니다.");
			return "recipe/errorPage"; // ✅ 수정
		}
	}

	private String saveImage(MultipartFile file, HttpServletRequest request) {
		if (file == null || file.isEmpty())
			return null;

		// 저장 경로 지정
		String uploadDir = "/resources/upload/recipe/";
		String realPath = servletContext.getRealPath(uploadDir);

		// 디렉토리 없으면 생성
		File dir = new File(realPath);
		if (!dir.exists())
			dir.mkdirs();

		// 고유한 파일명 생성 (예: UUID)
		String fileName = UUID.randomUUID().toString() + "_" + file.getOriginalFilename();
		File saveFile = new File(realPath, fileName);

		try {
			file.transferTo(saveFile);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}

		// 클라이언트 기준 경로 반환 (DB 저장용)
		return uploadDir + fileName;
	}
}
